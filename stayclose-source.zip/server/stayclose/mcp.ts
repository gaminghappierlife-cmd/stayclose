import type { Express, Request, Response } from "express";
import { initialState, type StayCloseState } from "../../shared/stayclose";

const protocol = "2025-11-25";
let state: StayCloseState = structuredClone(initialState);
const sessions = new Set<string>();
const allowedOrigins = new Set(["null", "http://localhost:3000"]);

function jsonRpc(id: unknown, result: unknown) { return { jsonrpc: "2.0", id, result }; }
function error(id: unknown, code: number, message: string) { return { jsonrpc: "2.0", id, error: { code, message } }; }
function tools() { return [
  { name: "read_home_status", description: "Read the resident's simulated home status and recent events.", inputSchema: { type: "object", properties: {} } },
  { name: "prepare_assistance_request", description: "Prepare a consent-based request to a trusted contact. Does not send a message.", inputSchema: { type: "object", properties: { contactId: { type: "string" }, reason: { type: "string" } }, required: ["contactId", "reason"] } },
  { name: "confirm_assistance_request", description: "Record a simulated request after resident confirmation.", inputSchema: { type: "object", properties: { contactId: { type: "string" }, reason: { type: "string" } }, required: ["contactId", "reason"] } },
  { name: "simulate_assistance_dog_signal", description: "Simulate a deliberate assistance-dog switch signal and ask for a check-in.", inputSchema: { type: "object", properties: {} } },
  { name: "create_delivery_note", description: "Create a dog-aware delivery note for the resident to copy or share.", inputSchema: { type: "object", properties: { dogName: { type: "string" } }, required: ["dogName"] } },
]; }
function text(value: unknown) { return [{ type: "text", text: typeof value === "string" ? value : JSON.stringify(value) }]; }

export function registerMcp(app: Express) {
  app.post("/api/mcp", (req: Request, res: Response) => {
    const origin = req.header("origin");
    if (origin && !allowedOrigins.has(origin) && !origin.startsWith("https://") && !origin.startsWith("http://localhost") && !origin.startsWith("http://127.0.0.1")) return res.status(403).json(error(null, -32000, "Invalid Origin"));
    const message = req.body;
    if (!message || message.jsonrpc !== "2.0") return res.status(400).json(error(null, -32600, "Invalid JSON-RPC message"));
    const id = message.id ?? null;
    if (message.method === "initialize") {
      const session = crypto.randomUUID(); sessions.add(session);
      res.setHeader("MCP-Session-Id", session).setHeader("MCP-Protocol-Version", protocol);
      return res.json(jsonRpc(id, { protocolVersion: protocol, capabilities: { tools: {} }, serverInfo: { name: "stayclose", version: "0.1.0" } }));
    }
    const session = req.header("mcp-session-id");
    if (session && !sessions.has(session)) return res.status(404).json(error(id, -32001, "Session not found"));
    if (message.method === "notifications/initialized" || message.method === "notifications/cancelled") return res.status(202).end();
    if (message.method === "tools/list") return res.json(jsonRpc(id, { tools: tools() }));
    if (message.method === "tools/call") {
      const name = message.params?.name; const args = message.params?.arguments ?? {};
      if (name === "read_home_status") return res.json(jsonRpc(id, { content: text(state), structuredContent: state }));
      if (name === "prepare_assistance_request") { const contact = state.contacts.find(c => c.id === args.contactId); return res.json(jsonRpc(id, { content: text(contact ? `Ready to ask ${contact.name}: ${args.reason}. Please confirm.` : "Contact not found."), structuredContent: { contact, requiresConfirmation: true } })); }
      if (name === "confirm_assistance_request") { const contact = state.contacts.find(c => c.id === args.contactId); state = { ...state, homeState: "assistance-requested", lastAction: `Simulated request prepared for ${contact?.name ?? "trusted contact"}`, events: [{ id: crypto.randomUUID(), kind: "contact", title: "Assistance request confirmed", detail: `Prepared for ${contact?.name ?? "trusted contact"}; no message was sent`, time: "Just now", tone: "urgent", simulated: true }, ...state.events] }; return res.json(jsonRpc(id, { content: text("Confirmation recorded. This prototype did not send an SMS or call emergency services."), structuredContent: state })); }
      if (name === "simulate_assistance_dog_signal") { state = { ...state, assistanceDogTriggered: true, homeState: "attention", lastAction: `Check-in requested by ${state.dogName}`, events: [{ id: crypto.randomUUID(), kind: "dog", title: `${state.dogName} signal received`, detail: "Deliberate simulator trigger; check-in needed", time: "Just now", tone: "notice", simulated: true }, ...state.events] }; return res.json(jsonRpc(id, { content: text(`A check-in is ready because ${state.dogName}'s deliberate signal was received.`), structuredContent: state })); }
      if (name === "create_delivery_note") return res.json(jsonRpc(id, { content: text(`Please wait at the door. The resident may take a little longer. An assistance dog is working; please do not distract or feed the dog.`), structuredContent: { note: "Please wait at the door. The resident may take a little longer. An assistance dog is working; please do not distract or feed the dog." } }));
      return res.json(error(id, -32601, "Unknown tool"));
    }
    return res.json(error(id, -32601, "Method not found"));
  });
  app.get("/api/mcp", (_req, res) => res.status(405).setHeader("Allow", "POST").json({ error: "Use POST for MCP JSON-RPC messages" }));
}
