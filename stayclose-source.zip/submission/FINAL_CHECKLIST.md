# StayClose competition submission checklist

## Already included in this package

- Working Alexa+ simulated experience.
- Self-hosted MCP endpoint at `POST /api/mcp`.
- MCP protocol version `2025-11-25` in initialization and subsequent requests.
- Accessible responsive UI with bedside mode, large controls, keyboard focus, status messaging and reduced-motion support.
- Ecosystem map with Alexa+, Ring, Apple Watch, Phone Messages, Uber Eats and WhatsApp/care-circle logos.
- MIT licence.
- Setup instructions and repository map.
- Devpost project description, product feedback, safety notes and demo script.
- Research notes and explicit integration boundaries.

## Entrant actions still required

1. Join the competition and confirm eligibility under the official rules.
2. Create or connect a GitHub repository and upload this source package. Keep the repository public with the included MIT licence, or share a private repository with the required Devpost/Amazon reviewers.
3. Record an English public YouTube or Vimeo demo under three minutes using the script in `docs/DEVPOST.md`.
4. In the video, show the app working and make the simulated-home label visible. Show the MCP-backed actions, dog-signal workflow, confirmation step and bedside mode.
5. Paste the description, track selection and product feedback from `docs/DEVPOST.md` into Devpost.
6. Select **Alexa+** as the primary track. Do not select AWS Builder or Open Source unless you separately complete their additional requirements.
7. Replace any demo contact names or sample details before a public production deployment. Do not record or publish real private contact information.
8. Submit before the official deadline shown on the competition page. Do not claim live Ring, Apple Watch, Uber Eats, WhatsApp or SMS connectivity unless separately implemented and tested.

## Suggested final video order

Open on the message “For people who cannot always get up” and the “SIMULATED HOME” label. Show home status, prepare the working-dog delivery note, trigger the deliberate dog signal, ask a trusted contact for a hand, confirm the request, then show the interconnected service map and bedside mode.
