# StayClose demo assets

## Image demo

[Open the full-page StayClose product capture](https://files.manuscdn.com/user_upload_by_module/session_file/310519664035199751/CYNBgSQjUjqHgNMe.png)

## One-minute narrated video demo

[Open the narrated StayClose showpiece](https://files.manuscdn.com/user_upload_by_module/session_file/310519664035199751/PNaZSgRaGzkWfCmx.mp4)

The final video is a 60-second, 1280×720 MP4 with a warm English voiceover. It moves through six beats: the accessibility need, home awareness, trusted assistance, working-dog-aware arrivals, the connected-service ecosystem and the consent boundary. The visual layers are captured from the real StayClose interface, with readable lower-thirds to keep the story clear for judges.

This is a direct MP4 asset, not a YouTube or Vimeo upload. If the competition form requires a public YouTube/Vimeo URL, upload this MP4 there and use that resulting public URL in Devpost.

The image and video show the current prototype honestly: Alexa+ MCP is the working prototype path; Ring, Apple Watch, phone messaging, Uber Eats and WhatsApp/care circles are shown as planned or user-controlled connection points.
