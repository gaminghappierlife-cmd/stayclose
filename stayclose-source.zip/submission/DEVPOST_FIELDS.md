# Devpost field copy

## Project title
StayClose — Home within reach

## Tagline
A consent-first Alexa+ bedside companion for people who cannot always get up.

## Primary track
Alexa+

## Short description
StayClose gives disabled and severely disabled people a calm way to understand what is happening at home, request trusted help and prepare assistance-dog-aware delivery instructions without leaving bed. It is a working Alexa+ MCP prototype with an accessible simulated experience.

## Required honesty note
The demo uses simulated home events and browser-session data. Alexa+ MCP is working in the prototype. Ring, Apple Watch, phone messaging, Uber Eats and WhatsApp are shown as planned or user-controlled connection points, not live integrations. StayClose does not dispatch emergency services, unlock doors, place orders or send messages automatically.

## Judging angle
The project focuses on accessibility and caretaking while using the required Alexa+ technology directly. Its differentiator is not another smart-home dashboard; it is an interaction layer that makes safety-related context and trusted assistance reachable from bed, with explicit consent and visible failure boundaries.
