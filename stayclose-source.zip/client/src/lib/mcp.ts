let sessionId = "";
let initialized = false;
export async function mcpCall<T>(method: string, params?: unknown): Promise<T> {
  if (!initialized) { const init = await fetch("/api/mcp", { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion: "2025-11-25", capabilities: {}, clientInfo: { name: "stayclose-simulator", version: "0.1.0" } } }) }); sessionId = init.headers.get("MCP-Session-Id") ?? ""; initialized = true; await fetch("/api/mcp", { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream", "MCP-Session-Id": sessionId, "MCP-Protocol-Version": "2025-11-25" }, body: JSON.stringify({ jsonrpc: "2.0", method: "notifications/initialized" }) }); }
  const response = await fetch("/api/mcp", { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream", "MCP-Session-Id": sessionId, "MCP-Protocol-Version": "2025-11-25" }, body: JSON.stringify({ jsonrpc: "2.0", id: Date.now(), method, params }) });
  const payload = await response.json(); if (payload.error) throw new Error(payload.error.message); return payload.result as T;
}
export const callTool = <T>(name: string, args: Record<string, unknown> = {}) => mcpCall<T>("tools/call", { name, arguments: args });
