# StayClose — Devpost submission kit

## One-line pitch
StayClose is an Alexa+ MCP companion that gives people who cannot readily get up a calm, consent-first way to understand the home, request trusted help and prepare dog-aware delivery instructions from bed.

## Description
StayClose turns the Alexa+ MCP pattern into an accessible bedside control surface. A resident can read a simulated home status, review front-door activity, trigger a deliberate assistance-dog check-in, prepare a delivery note for a working dog and ask a trusted contact for help. Sensitive help requests always stop for confirmation. The demo never silently contacts a person, unlocks a door, orders food or claims emergency response.

The prototype includes a real self-hosted Streamable HTTP MCP endpoint at `/api/mcp`, implementing JSON-RPC initialization, negotiated protocol version `2025-11-25`, session headers, tool discovery and tool calls. Its web UI acts as a simulated Alexa+ client and shows tool responses as resident-facing actions. The server uses an Origin check and expires unknown sessions. The five demo tools are `read_home_status`, `prepare_assistance_request`, `confirm_assistance_request`, `simulate_assistance_dog_signal` and `create_delivery_note`.

The design is intentionally honest about the frontier between a competition prototype and a production service. Ring, Apple Watch, Uber Eats and SMS are shown as planned adapters rather than connected accounts. A production build would add user authentication, consent records, scoped device access, encrypted storage, verified Ring webhooks and an approved notification provider. StayClose is not an emergency service; the demo directs a resident to the phone's native emergency/SOS path for a real emergency.

## Track and mini-challenge
Primary: Alexa+.

Do not select AWS Builder or Open Source unless the entrant has separately completed and can link those requirements.

## Demo script (under three minutes)

1. Open StayClose and point out the visible `SIMULATED HOME` label and `Private by design` note.
2. Say/type: “Read my home status.” Show the MCP-backed `All clear` response.
3. Select `Prepare delivery note`. Show the assistance-dog language and copy action. Explain that this is a resident-controlled note, not an automatic courier integration.
4. Select `Signal a check-in`. Show the simulated dog signal and the new attention state.
5. Select a trusted contact. Show the confirmation dialog. Confirm it and point out the explicit “no SMS or emergency call” boundary.
6. Toggle `Bedside mode` to enlarge the high-value actions. End on the planned integrations cards and the sentence “Your home, within reach.”

## Setup

```bash
pnpm install
pnpm dev
```

Open the local preview. The MCP endpoint is `POST /api/mcp`. `GET /api/mcp` intentionally returns `405` because this implementation uses JSON responses rather than server-sent event streaming for the demo request path.

## Product feedback

The MCP protocol is a strong fit for an assistant that must discover a small set of resident-safe actions. JSON-RPC and the Streamable HTTP shape make the integration inspectable without an Echo device. The main friction is that session, authentication, consent, and durable audit semantics remain application responsibilities. For a production accessibility service, official reference patterns for confirmation, account linking, provider scopes and accessible error states would reduce risk. We would build with MCP again, but only behind a narrow, typed tool surface and explicit confirmation policy.

## Safety and accessibility notes

No medical, emergency-response or disability-performance claim is made. The dog signal is a deliberate simulator event, not bark recognition or fall detection. The UI supports keyboard navigation, large controls, screen-reader labels, high-contrast text, status announcements, reduced motion and bedside mode. Real users with disabilities should be involved in co-design and testing before deployment.
