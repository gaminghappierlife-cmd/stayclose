# StayClose — Home within reach

## Proposed product and competition strategy

Build a working Alexa+ track entry for the 23 October 2026, 19:00 UTC deadline. StayClose is an accessible bedside companion that brings a home overview, consent-based assistance, assistance-dog triggers and delivery instructions into one control surface. The product's strongest demonstration is a resident who can remain in bed, review a simulated front-door event, prepare a dog-aware delivery note, ask a trusted contact for help, and cancel a false assistance-dog alert. No competition outcome is guaranteed.

Use the contest's explicit simulated-Alexa+ path. Implement an actual MCP server using the official TypeScript SDK, minimum negotiated version 2025-11-25, via Streamable HTTP at `/api/mcp`. The web app is a clearly labelled Alexa+ experience simulator that calls the MCP tools over HTTP. Deterministic, inspectable command routing avoids unneeded model charges and unpredictable safety actions. Browser microphone transcription and speech synthesis are optional conveniences; typed commands, keyboard and large touch targets provide equivalent controls. No always-listening microphone.

## Working prototype scope

The responsive home overview offers bedside mode, simulated front-door status and events, a security/privacy view, an activity trail, and large actions. A simulated home never claims to be monitored or secured in real life. No unlock action is provided.

A trusted-contact editor saves demo contacts to the browser's session state. Assistance requires preview and explicit confirmation, then displays a simulated contact delivery with staged acknowledgement and escalation. Cancel and acknowledge transitions are visible. No SMS provider is attached; external delivery is never described as real. Phone/SMS composer links may be offered for user-controlled handoff, clearly distinguished from sending.

An assistance-dog section configures a demo dog identity and a deliberate trained switch trigger. Triggering it opens a check-in workflow. It does not classify barking, diagnose illness, or infer a fall. Dog alerts alone do not silently send messages or dispatch services.

A delivery-note editor produces a minimal, dog-aware message: please wait, the resident may take longer, and do not distract or feed the working dog. Copy/share hands it to the user's phone. An Uber Eats link opens the service; StayClose does not order, pay, read orders or message a driver automatically. Apple Watch is presented as a planned native adapter, not a connected wearable. Ring is a simulated event concept, not a claimed Ring-track integration.

An integrations page shows actual prototype functions separately from planned provider integrations. It exposes real MCP connection instructions and tool results. Prototype data is per-browser/session, with no durable patient record or real household data. The backend rejects invalid origins, isolates expiring sessions, limits input and makes all tools demo-only. Production needs authentication, account linking, consent, durable encrypted storage, notification-provider integration and accessibility co-design.

An emergency-information panel says this is not an emergency service. It displays instructions to use a phone's native emergency call / SOS; it never calls emergency services or promises response. The user can customise their local emergency number for reference, but no accidental real-emergency call is available in the public demo.

## Submission materials

Provide source with MIT license, run instructions, architecture, recorded implementation feedback and reproducible demo script under three minutes, plus a ready-to-paste Devpost description. A source ZIP is delivered. A GitHub repository and public YouTube/Vimeo video are required for final entry. User account access and approval of contest terms remain necessary; do not invent identities or submit without the user's final approval. Do not claim AWS or Open Source mini-challenge eligibility unless its additional requirements are actually fulfilled. No purchased hardware, AWS provisioning, SMS subscription, or paid runtime AI is needed for this prototype. Manus account credit availability cannot be verified or guaranteed here.

## Implementation and serving

Use the initialized React/TypeScript/Vite and Express project. `server/stayclose/` contains state transitions and MCP registration; `shared/stayclose.ts` owns types. `client/src/lib/mcp.ts` owns HTTP initialization and tool calls. `client/src/pages/Home.tsx` and `client/src/components/stayclose/` contain accessible views; `client/src/index.css` contains the design system. `docs/` contains submission and safety material; `server/stayclose/*.test.ts` checks transitions. Build using the existing locked pnpm toolchain and Dockerfile; Express serves bundled frontend and `/api/mcp` from one origin. Route manifest matches the single-page source. Save a managed checkpoint, then request publication for the demo.

## Design

Three considered directions: Warm modernist care console (probability 0.07), high-contrast Swiss utility (0.04), quiet Japanese domestic minimalism (0.03). Choose warm modernist care console.

**Design movement:** Scandinavian human-centred modernism with editorial clarity, not hospital styling.

**Core principles:** calm before urgency; resident agency; obvious prototype boundaries; tactile, easy-to-target controls.

**Color philosophy:** warm off-white reduces harshness, deep ink makes text legible, forest-teal marks agency, restrained amber marks uncertainty. Red is reserved for assistance warnings, not decoration.

**Layout paradigm:** left navigation rail, a broad asymmetric content column, and a narrow activity/assistance companion rail. On phone the rail becomes a compact scrollable navigation row and content follows reading order. Bedside mode removes peripheral density and enlarges primary controls.

**Signature elements:** an open-door-shaped monogram; pill-shaped status markers; understated curved line illustration of a home in the hero card.

**Interaction philosophy:** one clear action per prompt; reversible simulation; explicit confirmation for sensitive actions; no hidden timer escalation; visible focus and polite live regions.

**Animation:** brief 160ms color/opacity transitions; no pulsing alarm animation; respect prefers-reduced-motion; never make motion necessary to understand status.

**Typography:** DM Sans for UI and Fraunces for restrained editorial headlines with system fallbacks. Labels at least 13px; body at least 16px; controls at least 48px; large text toggle and clear focus outlines.

**Brand essence:** control of the home from where you are, for people who cannot readily get up. Calm, capable, considerate.

**Brand voice:** direct and dignified. Examples: 'Your home, within reach.' and 'Let someone know you need a hand.' Do not speak for disabled users or claim clinical validation.

**Wordmark and logo:** StayClose with a geometric doorway monogram, using an interrupted enclosing stroke to suggest access rather than surveillance.

**Signature brand color:** deep woodland teal, #235D50.
