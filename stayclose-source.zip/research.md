# StayClose research

The submission deadline is 23 October 2026 at 19:00 UTC, equivalent to 12:00 Pacific Daylight Time and 20:00 British Summer Time. At the user's request there were 2 days, 21 hours, 35 minutes remaining. The Alexa+ track accepts a self-hosted MCP server implementing specification 2025-11-25 or later, using Streamable HTTP. A simulated Alexa+ experience is explicitly allowed. A source repository, English public YouTube/Vimeo demo shorter than three minutes, project description and honest product feedback are required. [1] [2] [3]

The rules prohibit ineligible entrants and require the entrant to accept their contractual terms. The user must verify age, residence and conflict-of-interest eligibility and approve final submission. AWS promotional credit codes are exhausted according to the October 7 update. No AWS integration is necessary for the primary Alexa+ track. [2] [3]

Ring's event and video APIs can support an accessibility companion with user-authorized access, but the documentation does not establish a general courier-message, emergency-dispatch or native dog-recognition API. Ring webhooks require HMAC verification and prompt acknowledgement. Real deployment requires onboarding, permissions and appropriate data security. Use an explicitly labelled simulated home for this Alexa+ entry, not an unsupported claim of live Ring integration. [4] [5] [6]

MCP Streamable HTTP uses JSON-RPC requests via POST and permits a JSON response. GET may return 405 if no SSE stream is offered. Clients advertise application/json and text/event-stream and use MCP-Protocol-Version after initialization. Validate Origin; session identifiers are not authentication. [7]

Scope recommendation: a narrowly demonstrated bedside assistance workflow, with actual MCP tools and a web client that invokes them. Demo-only contact escalation must never say an SMS has been delivered. Dog events should be a configurable physical-switch concept, demonstrated by an explicit simulator, not barking diagnosis or fall detection. Unknown visitors do not become identified safe people. No remote unlocking, medical conclusions, auto-ordering, or emergency dispatch.

## References

[1]: https://amazonappdev2026.devpost.com/ "Official competition overview and requirements"
[2]: https://amazonappdev2026.devpost.com/rules "Official competition rules"
[3]: https://amazonappdev2026.devpost.com/resources "Official developer resources"
[4]: https://developer.amazon.com/docs/ring/get-started.html "Ring getting started"
[5]: https://developer.amazon.com/docs/ring/api-documentation.html "Ring Partner API documentation"
[6]: https://developer.amazon.com/docs/ring/computer-vision-guidelines.html "Ring computer vision guidelines"
[7]: https://modelcontextprotocol.io/specification/2025-11-25/basic/transports "MCP Streamable HTTP specification"
