export type HomeState = "all-clear" | "attention" | "assistance-requested";
export type EventKind = "door" | "dog" | "delivery" | "contact";

export interface Contact { id: string; name: string; relationship: string; channel: "phone" | "sms" | "app"; value: string; }
export interface HomeEvent { id: string; kind: EventKind; title: string; detail: string; time: string; tone: "calm" | "notice" | "urgent"; simulated: true; }
export interface StayCloseState { homeState: HomeState; dogName: string; assistanceDogTriggered: boolean; contacts: Contact[]; events: HomeEvent[]; lastAction?: string; }

export const initialState: StayCloseState = {
  homeState: "all-clear", dogName: "Milo", assistanceDogTriggered: false,
  contacts: [
    { id: "c1", name: "Jordan Lee", relationship: "trusted contact", channel: "sms", value: "+44 7700 900 321" },
    { id: "c2", name: "Care team", relationship: "support circle", channel: "phone", value: "+44 20 7946 0958" },
  ],
  events: [
    { id: "e1", kind: "door", title: "Front door is closed", detail: "No unreviewed activity", time: "Just now", tone: "calm", simulated: true },
    { id: "e2", kind: "contact", title: "StayClose is ready", detail: "Bedside mode is on", time: "Today", tone: "calm", simulated: true },
  ],
};

export function addEvent(state: StayCloseState, event: Omit<HomeEvent, "id" | "time" | "simulated">): StayCloseState {
  return { ...state, events: [{ ...event, id: crypto.randomUUID(), time: "Just now", simulated: true as const }, ...state.events].slice(0, 8) };
}
